/**
 * JavaScript para Lluvia Nieve Administracion
 * @version 1 (31. Dic 2013)
 * @author @jbravot (jonathan Bravo)
 * @requires jQuery
 * @see jonathanbravo.com
 */
(function ($){$(document).ready(function(){$("#edit-lluvianieve-color").colorPicker();});})(jQuery)